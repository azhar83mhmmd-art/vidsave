/* ═══════════════════════════════════════════════════
   TIKSAVE PRO — script.js
   API: tikwm.com (proxy-free, direct call)
   Premium: localStorage simulation
═══════════════════════════════════════════════════ */

"use strict";

/* ─── CONSTANTS ─── */
const API_BASE    = "https://www.tikwm.com/api/";
const HISTORY_KEY = "tiksave_history";
const PREMIUM_KEY = "premium";
const MAX_HISTORY = 8;

/* ─── STATE ─── */
let currentData = null;  // holds last fetched video data

/* ─── DOM REFS ─── */
const urlInput         = document.getElementById("url-input");
const grabBtn          = document.getElementById("grab-btn");
const btnText          = document.getElementById("btn-text");
const clearBtn         = document.getElementById("clear-btn");
const loadingEl        = document.getElementById("loading");
const errorBox         = document.getElementById("error-box");
const errorMsg         = document.getElementById("error-msg");
const errorDismiss     = document.getElementById("error-dismiss");
const resultCard       = document.getElementById("result-card");
const resultThumb      = document.getElementById("result-thumb");
const resultDuration   = document.getElementById("result-duration");
const resultAuthor     = document.getElementById("result-author");
const resultTitle      = document.getElementById("result-title");
const statsRow         = document.getElementById("stats-row");
const btnSd            = document.getElementById("btn-sd");
const btnHd            = document.getElementById("btn-hd");
const btnCopy          = document.getElementById("btn-copy");
const copyText         = document.getElementById("copy-text");
const upgradeBtn       = document.getElementById("upgrade-btn");
const premiumStatus    = document.getElementById("premium-status");
const popupOverlay     = document.getElementById("popup-overlay");
const upgradeConfirm   = document.getElementById("upgrade-confirm-btn");
const popupClose       = document.getElementById("popup-close-btn");
const toast            = document.getElementById("toast");
const historySection   = document.getElementById("history-section");
const historyList      = document.getElementById("history-list");
const clearHistoryBtn  = document.getElementById("clear-history-btn");

/* ════════════════════════════════════════════════
   PREMIUM SYSTEM
════════════════════════════════════════════════ */
function isPremium() {
  return localStorage.getItem(PREMIUM_KEY) === "true";
}

function activatePremium() {
  localStorage.setItem(PREMIUM_KEY, "true");
  updatePremiumUI();
  showToast("⚡ Premium aktif! Selamat menikmati HD download 🎉");
  closePopup();
}

function updatePremiumUI() {
  if (isPremium()) {
    premiumStatus.style.display = "inline-block";
    upgradeBtn.textContent      = "✓ Premium Aktif";
    upgradeBtn.style.background = "#39ff14";
    upgradeBtn.style.cursor     = "default";
  } else {
    premiumStatus.style.display = "none";
    upgradeBtn.textContent      = "⚡ Upgrade Premium";
    upgradeBtn.style.background = "";
    upgradeBtn.style.cursor     = "";
  }
}

/* ════════════════════════════════════════════════
   TOAST
════════════════════════════════════════════════ */
let toastTimer = null;
function showToast(msg, duration = 3000) {
  toast.textContent = msg;
  toast.classList.add("show");
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), duration);
}

/* ════════════════════════════════════════════════
   POPUP
════════════════════════════════════════════════ */
function openPopup() {
  popupOverlay.style.display = "flex";
  document.body.style.overflow = "hidden";
}
function closePopup() {
  popupOverlay.style.display = "none";
  document.body.style.overflow = "";
}

/* ════════════════════════════════════════════════
   UI STATE HELPERS
════════════════════════════════════════════════ */
function hideAll() {
  loadingEl.style.display = "none";
  errorBox.style.display  = "none";
  resultCard.style.display = "none";
}

function showLoading() {
  hideAll();
  loadingEl.style.display = "flex";
  grabBtn.disabled = true;
  btnText.textContent = "Processing...";
}

function showError(msg) {
  hideAll();
  errorMsg.textContent = msg;
  errorBox.style.display = "flex";
  grabBtn.disabled = false;
  btnText.textContent = "DOWNLOAD";
}

function showResult() {
  loadingEl.style.display = "none";
  errorBox.style.display  = "none";
  resultCard.style.display = "block";
  grabBtn.disabled = false;
  btnText.textContent = "DOWNLOAD";
}

/* ════════════════════════════════════════════════
   FORMAT HELPERS
════════════════════════════════════════════════ */
function fmtCount(n) {
  if (!n && n !== 0) return null;
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000)     return (n / 1_000).toFixed(1) + "K";
  return String(n);
}

function fmtDuration(secs) {
  if (!secs) return "";
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function timeAgo(ts) {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1)  return "Baru saja";
  if (mins < 60) return `${mins} menit lalu`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24)  return `${hrs} jam lalu`;
  return `${Math.floor(hrs / 24)} hari lalu`;
}

/* ════════════════════════════════════════════════
   VALIDATE URL
════════════════════════════════════════════════ */
function validateTikTokUrl(url) {
  return /https?:\/\/(www\.|vm\.|vt\.)?tiktok\.com\/.+/i.test(url);
}

/* ════════════════════════════════════════════════
   FETCH VIDEO
════════════════════════════════════════════════ */
async function fetchVideo() {
  const url = urlInput.value.trim();

  if (!url) {
    showError("Link TikTok tidak boleh kosong. Paste URL video TikTok-mu!");
    return;
  }
  if (!validateTikTokUrl(url)) {
    showError("URL tidak valid. Pastikan link dari tiktok.com, vm.tiktok.com, atau vt.tiktok.com.");
    return;
  }

  showLoading();

  try {
    const apiUrl = `${API_BASE}?url=${encodeURIComponent(url)}&hd=1`;
    const res = await fetch(apiUrl, {
      headers: {
        "Accept": "application/json",
      }
    });

    if (!res.ok) {
      throw new Error(`Server error: ${res.status}`);
    }

    const json = await res.json();

    if (json.code !== 0) {
      showError(json.msg || "Gagal memproses video. Cek URL dan coba lagi.");
      return;
    }

    const v = json.data;

    currentData = {
      id:       v.id,
      title:    v.title     || "TikTok Video",
      cover:    v.cover     || v.origin_cover || "",
      duration: v.duration  || 0,
      author: {
        name:     v.author?.nickname   || "Unknown",
        username: v.author?.unique_id  || "",
        avatar:   v.author?.avatar     || "",
      },
      stats: {
        plays:    v.play_count,
        likes:    v.digg_count,
        comments: v.comment_count,
        shares:   v.share_count,
      },
      downloads: {
        sd: v.play || "",
        hd: v.hdplay || v.play || "",
      }
    };

    renderResult(currentData);
    addToHistory(currentData, url);
    showResult();
    resultCard.scrollIntoView({ behavior: "smooth", block: "nearest" });

  } catch (err) {
    console.error("[TikSave Error]", err);
    if (err.message.includes("Failed to fetch") || err.message.includes("NetworkError")) {
      showError("Gagal terhubung ke server. Periksa koneksi internet kamu.");
    } else {
      showError("Terjadi kesalahan saat memproses video. Coba lagi dalam beberapa saat.");
    }
  }
}

/* ════════════════════════════════════════════════
   RENDER RESULT
════════════════════════════════════════════════ */
function renderResult(data) {
  /* Thumbnail */
  resultThumb.src   = data.cover;
  resultThumb.alt   = data.title;

  /* Duration */
  const dur = fmtDuration(data.duration);
  resultDuration.textContent  = dur;
  resultDuration.style.display = dur ? "inline-block" : "none";

  /* Author & Title */
  resultAuthor.textContent = data.author.username
    ? `@${data.author.username}`
    : data.author.name;
  resultTitle.textContent  = data.title;

  /* Stats */
  const chips = [
    { icon: "▶", v: data.stats.plays,    l: "plays"    },
    { icon: "♥", v: data.stats.likes,    l: "likes"    },
    { icon: "💬", v: data.stats.comments, l: "comments" },
    { icon: "↗", v: data.stats.shares,   l: "shares"   },
  ].filter(c => c.v);

  statsRow.innerHTML = chips.map(c =>
    `<span class="stat-chip">${c.icon} ${fmtCount(c.v)}</span>`
  ).join("");

  /* SD button link */
  if (data.downloads.sd) {
    btnSd.href = data.downloads.sd;
    btnSd.style.display = "flex";
  } else {
    btnSd.style.display = "none";
  }

  /* HD button — store URL in data attr */
  btnHd.dataset.hdUrl = data.downloads.hd || "";
}

/* ════════════════════════════════════════════════
   DOWNLOAD HD LOGIC
════════════════════════════════════════════════ */
function handleHdClick() {
  const hdUrl = btnHd.dataset.hdUrl;
  if (!hdUrl) { showToast("Link HD tidak tersedia untuk video ini."); return; }

  if (!isPremium()) {
    openPopup();
  } else {
    const a = document.createElement("a");
    a.href     = hdUrl;
    a.target   = "_blank";
    a.rel      = "noopener noreferrer";
    a.download = "";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast("⬇ Download HD dimulai!");
  }
}

/* ════════════════════════════════════════════════
   COPY LINK
════════════════════════════════════════════════ */
function handleCopy() {
  if (!currentData) return;

  const urlToCopy = isPremium()
    ? (currentData.downloads.hd || currentData.downloads.sd)
    : currentData.downloads.sd;

  if (!urlToCopy) { showToast("Link tidak tersedia."); return; }

  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(urlToCopy).then(() => {
      copyText.textContent = "✓ Link Tersalin!";
      setTimeout(() => { copyText.textContent = "📋 Copy Link Download"; }, 2500);
      showToast("📋 Link berhasil disalin!");
    }).catch(() => fallbackCopy(urlToCopy));
  } else {
    fallbackCopy(urlToCopy);
  }
}

function fallbackCopy(text) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.cssText = "position:fixed;top:-9999px;left:-9999px;opacity:0";
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  document.execCommand("copy");
  document.body.removeChild(ta);
  copyText.textContent = "✓ Link Tersalin!";
  setTimeout(() => { copyText.textContent = "📋 Copy Link Download"; }, 2500);
  showToast("📋 Link berhasil disalin!");
}

/* ════════════════════════════════════════════════
   HISTORY
════════════════════════════════════════════════ */
function getHistory() {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveHistory(list) {
  localStorage.setItem(HISTORY_KEY, JSON.stringify(list));
}

function addToHistory(data, originalUrl) {
  const list = getHistory();
  // Remove duplicate by id
  const filtered = list.filter(h => h.id !== data.id);
  const entry = {
    id:          data.id,
    title:       data.title,
    cover:       data.cover,
    author:      data.author.username || data.author.name,
    originalUrl: originalUrl,
    timestamp:   Date.now(),
  };
  filtered.unshift(entry);
  saveHistory(filtered.slice(0, MAX_HISTORY));
  renderHistory();
}

function renderHistory() {
  const list = getHistory();
  if (!list.length) {
    historySection.style.display = "none";
    return;
  }

  historySection.style.display = "block";
  historyList.innerHTML = "";

  list.forEach(item => {
    const div = document.createElement("div");
    div.className = "history-item";
    div.innerHTML = `
      <img class="history-thumb" src="${item.cover}" alt="" loading="lazy" onerror="this.style.display='none'" />
      <span class="history-title-text">${item.title}</span>
      <span class="history-time">${timeAgo(item.timestamp)}</span>
    `;
    div.addEventListener("click", () => {
      urlInput.value = item.originalUrl;
      updateClearBtn();
      window.scrollTo({ top: 0, behavior: "smooth" });
      setTimeout(fetchVideo, 300);
    });
    historyList.appendChild(div);
  });
}

function clearHistory() {
  localStorage.removeItem(HISTORY_KEY);
  renderHistory();
  showToast("🗑 Riwayat dihapus.");
}

/* ════════════════════════════════════════════════
   CLEAR INPUT BTN
════════════════════════════════════════════════ */
function updateClearBtn() {
  clearBtn.style.display = urlInput.value.length > 0 ? "block" : "none";
}

/* ════════════════════════════════════════════════
   EVENT LISTENERS
════════════════════════════════════════════════ */

/* Input events */
urlInput.addEventListener("input", updateClearBtn);
urlInput.addEventListener("keydown", e => { if (e.key === "Enter") fetchVideo(); });
urlInput.addEventListener("paste", () => {
  setTimeout(updateClearBtn, 50);
});

clearBtn.addEventListener("click", () => {
  urlInput.value = "";
  updateClearBtn();
  hideAll();
  currentData = null;
  urlInput.focus();
});

/* Main download */
grabBtn.addEventListener("click", fetchVideo);

/* Error dismiss */
errorDismiss.addEventListener("click", () => {
  errorBox.style.display = "none";
});

/* HD download */
btnHd.addEventListener("click", handleHdClick);

/* Copy link */
btnCopy.addEventListener("click", handleCopy);

/* Navbar upgrade */
upgradeBtn.addEventListener("click", () => {
  if (isPremium()) {
    showToast("⚡ Kamu sudah Premium! Nikmati HD download tanpa batas.");
    return;
  }
  openPopup();
});

/* Popup actions */
upgradeConfirm.addEventListener("click", activatePremium);
popupClose.addEventListener("click", closePopup);
popupOverlay.addEventListener("click", e => {
  if (e.target === popupOverlay) closePopup();
});

/* History clear */
clearHistoryBtn.addEventListener("click", clearHistory);

/* Keyboard esc to close popup */
document.addEventListener("keydown", e => {
  if (e.key === "Escape" && popupOverlay.style.display !== "none") closePopup();
});

/* ════════════════════════════════════════════════
   INIT
════════════════════════════════════════════════ */
(function init() {
  updatePremiumUI();
  renderHistory();
  urlInput.focus();
})();
